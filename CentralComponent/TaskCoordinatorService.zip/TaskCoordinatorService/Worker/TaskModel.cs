namespace TaskCoordinatorService;

public class TaskModel
{
    public string Id { get; set; }
    public string Description { get; set; }
}
